/**
 * Enhanced CAPS Tools with Textbook Page Mapping Support
 * 
 * New Capabilities:
 * - Search CAPS topics by textbook page numbers
 * - Get learning objectives for specific lesson plan pages
 * - Generate exams aligned with textbook content
 * - Find textbook references for CAPS topics
 */

import type { ToolContext } from '../types.ts'

/**
 * Tool 1: Search CAPS by Textbook Page
 * 
 * Use Case: User uploads lesson plan showing "Pages 74-78"
 * Returns: CAPS topics covered on those pages with learning objectives
 */
export async function searchCAPSByTextbookPage(params: {
  textbook_title?: string
  textbook_isbn?: string
  grade: string
  subject: string
  page_start: number
  page_end?: number
}, context: ToolContext) {
  const { supabaseAdmin } = context
  
  console.log('[CAPS] Searching by page:', params)
  
  // Find textbook
  let textbookQuery = supabaseAdmin
    .from('textbooks')
    .select('id, title, publisher, page_count')
    .eq('grade', params.grade)
    .eq('subject', params.subject)
    .eq('is_active', true)
  
  if (params.textbook_isbn) {
    textbookQuery = textbookQuery.eq('isbn', params.textbook_isbn)
  } else if (params.textbook_title) {
    textbookQuery = textbookQuery.ilike('title', `%${params.textbook_title}%`)
  }
  
  const { data: textbooks, error: textbookError } = await textbookQuery
  
  if (textbookError || !textbooks || textbooks.length === 0) {
    return {
      success: false,
      message: `No textbook found for Grade ${params.grade} ${params.subject}${params.textbook_title ? ` (${params.textbook_title})` : ''}`,
      suggestion: 'Try specifying textbook title or ensure textbook is seeded in database'
    }
  }
  
  const textbook = textbooks[0]
  const pageEnd = params.page_end || params.page_start
  
  // Find CAPS topics via the mapping junction table
  const { data: mappings, error: mappingError } = await supabaseAdmin
    .rpc('find_caps_topics_by_page_range', {
      p_textbook_id: textbook.id,
      p_page_start: params.page_start,
      p_page_end: pageEnd
    })
  
  if (mappingError) {
    console.error('[CAPS] Mapping query error:', mappingError)
    // Fallback to direct query if RPC fails
    const { data: fallbackData, error: fallbackError } = await supabaseAdmin
      .from('caps_textbook_mapping')
      .select(`
        id,
        key_pages,
        coverage_percentage,
        alignment_score,
        caps_topics:caps_topic_id (
          id,
          topic_code,
          topic_title,
          content_outline,
          learning_outcomes,
          assessment_standards,
          skills_to_develop,
          cognitive_level,
          term
        ),
        textbook_content:textbook_content_id (
          title,
          page_start,
          page_end,
          key_concepts
        )
      `)
      .eq('textbook_content.textbook_id', textbook.id)
      .eq('status', 'verified')
    
    if (fallbackError) {
      throw new Error(`Failed to find CAPS mappings: ${fallbackError.message}`)
    }
    
    // Filter by page range manually
    const filtered = fallbackData?.filter((m: any) => {
      const content = m.textbook_content
      return content.page_start <= pageEnd && content.page_end >= params.page_start
    })
    
    return formatCAPSResults(filtered, textbook, params.page_start, pageEnd)
  }
  
  return formatCAPSResults(mappings, textbook, params.page_start, pageEnd)
}

/**
 * Tool 2: Get Textbook References for CAPS Topic
 * 
 * Use Case: User asks "Where can I find info about coal formation?"
 * Returns: All textbook pages that cover this topic
 */
export async function getTextbookReferencesForTopic(params: {
  topic_code?: string
  topic_title?: string
  grade: string
  subject: string
}, context: ToolContext) {
  const { supabaseAdmin } = context
  
  console.log('[CAPS] Finding textbook references for:', params)
  
  // Find the CAPS topic
  let topicQuery = supabaseAdmin
    .from('caps_topics')
    .select('*')
    .eq('grade', params.grade)
    .eq('subject', params.subject)
  
  if (params.topic_code) {
    topicQuery = topicQuery.eq('topic_code', params.topic_code)
  } else if (params.topic_title) {
    topicQuery = topicQuery.ilike('topic_title', `%${params.topic_title}%`)
  }
  
  const { data: topics, error: topicError } = await topicQuery
  
  if (topicError || !topics || topics.length === 0) {
    return {
      success: false,
      message: `No CAPS topic found matching criteria`,
      available_topics_hint: 'Try searching CAPS curriculum first to find topic codes'
    }
  }
  
  const topic = topics[0]
  
  // Get all textbook mappings for this topic
  const { data: references, error: refError } = await supabaseAdmin
    .from('caps_textbook_mapping')
    .select(`
      id,
      key_pages,
      diagram_pages,
      example_pages,
      exercise_pages,
      coverage_percentage,
      alignment_score,
      is_primary_reference,
      textbook_content:textbook_content_id (
        title,
        page_start,
        page_end,
        content_type,
        key_concepts,
        textbook:textbook_id (
          title,
          publisher,
          isbn,
          publication_year
        )
      )
    `)
    .eq('caps_topic_id', topic.id)
    .in('status', ['verified', 'approved'])
    .order('alignment_score', { ascending: false })
  
  if (refError) {
    throw new Error(`Failed to get textbook references: ${refError.message}`)
  }
  
  if (!references || references.length === 0) {
    return {
      success: true,
      topic: {
        code: topic.topic_code,
        title: topic.topic_title,
        grade: topic.grade,
        subject: topic.subject
      },
      references: [],
      message: 'This topic exists in CAPS but no textbook pages have been mapped yet'
    }
  }
  
  return {
    success: true,
    topic: {
      code: topic.topic_code,
      title: topic.topic_title,
      content_outline: topic.content_outline,
      learning_outcomes: topic.learning_outcomes,
      term: topic.term
    },
    references: references.map((ref: any) => ({
      textbook: {
        title: ref.textbook_content.textbook.title,
        publisher: ref.textbook_content.textbook.publisher,
        year: ref.textbook_content.textbook.publication_year
      },
      chapter: ref.textbook_content.title,
      pages: {
        full_range: `${ref.textbook_content.page_start}-${ref.textbook_content.page_end}`,
        key_pages: ref.key_pages,
        diagrams: ref.diagram_pages,
        examples: ref.example_pages,
        exercises: ref.exercise_pages
      },
      quality: {
        coverage: `${ref.coverage_percentage}%`,
        alignment_score: `${ref.alignment_score}/5`,
        is_primary: ref.is_primary_reference
      },
      key_concepts: ref.textbook_content.key_concepts
    })),
    count: references.length
  }
}

/**
 * Tool 3: Enhanced Exam Generation with Page-Specific Content
 * 
 * Use Case: Generate exam from lesson plan covering specific pages
 * Returns: Questions aligned with exact content taught
 */
export async function generateExamFromLessonPlan(params: {
  grade: string
  subject: string
  pages_covered: number[]  // e.g., [74, 75, 76, 78]
  question_types?: string[]
  num_questions?: number
  textbook_title?: string
}, context: ToolContext) {
  const { supabaseAdmin } = context
  
  console.log('[CAPS] Generating exam from lesson plan pages:', params)
  
  if (!params.pages_covered || params.pages_covered.length === 0) {
    return {
      success: false,
      message: 'Please specify which pages were covered in the lesson'
    }
  }
  
  // Find all CAPS topics covered in these pages
  const pageStart = Math.min(...params.pages_covered)
  const pageEnd = Math.max(...params.pages_covered)
  
  const topicsResult = await searchCAPSByTextbookPage({
    grade: params.grade,
    subject: params.subject,
    page_start: pageStart,
    page_end: pageEnd,
    textbook_title: params.textbook_title
  }, context)
  
  if (!topicsResult.success || !topicsResult.topics || topicsResult.topics.length === 0) {
    return {
      success: false,
      message: 'Could not find CAPS topics for the specified pages',
      hint: 'Ensure textbook-to-CAPS mappings exist for these pages'
    }
  }
  
  // Build exam specification
  const examSpec = {
    grade: params.grade,
    subject: params.subject,
    topics_covered: topicsResult.topics.map((t: any) => ({
      code: t.topic_code,
      title: t.topic_title,
      learning_outcomes: t.learning_outcomes,
      cognitive_level: t.cognitive_level,
      pages: t.pages_covered
    })),
    question_distribution: distributeQuestions(
      params.num_questions || 10,
      topicsResult.topics.length,
      params.question_types || ['multiple_choice', 'short_answer', 'long_answer']
    ),
    lesson_plan_pages: params.pages_covered,
    textbook: topicsResult.textbook
  }
  
  return {
    success: true,
    exam_specification: examSpec,
    message: 'Exam specification ready. Use this to generate specific questions.',
    next_step: 'Call generate_caps_exam tool with this specification'
  }
}

// =====================================================
// Helper Functions
// =====================================================

function formatCAPSResults(mappings: any[], textbook: any, pageStart: number, pageEnd: number) {
  if (!mappings || mappings.length === 0) {
    return {
      success: true,
      topics: [],
      textbook: {
        title: textbook.title,
        publisher: textbook.publisher
      },
      pages_searched: `${pageStart}-${pageEnd}`,
      message: 'No CAPS topics mapped to these pages yet. Manual mapping required.'
    }
  }
  
  return {
    success: true,
    textbook: {
      title: textbook.title,
      publisher: textbook.publisher,
      total_pages: textbook.page_count
    },
    pages_searched: `${pageStart}-${pageEnd}`,
    topics: mappings.map((m: any) => {
      const topic = m.caps_topics || m.caps_topic
      const content = m.textbook_content
      
      return {
        topic_code: topic.topic_code,
        topic_title: topic.topic_title,
        content_outline: topic.content_outline,
        learning_outcomes: topic.learning_outcomes || [],
        assessment_standards: topic.assessment_standards || [],
        skills_to_develop: topic.skills_to_develop || [],
        cognitive_level: topic.cognitive_level,
        term: topic.term,
        
        // Page mapping details
        pages_covered: m.key_pages || [content.page_start, content.page_end],
        chapter_title: content.title,
        key_concepts: content.key_concepts || [],
        
        // Quality indicators
        coverage: `${m.coverage_percentage}%`,
        alignment_score: `${m.alignment_score}/5`
      }
    }),
    count: mappings.length,
    teaching_guidance: generateTeachingGuidance(mappings)
  }
}

function generateTeachingGuidance(mappings: any[]) {
  const allOutcomes = mappings
    .flatMap((m: any) => (m.caps_topics || m.caps_topic).learning_outcomes || [])
    .filter((o: string, i: number, arr: string[]) => arr.indexOf(o) === i)
  
  const allSkills = mappings
    .flatMap((m: any) => (m.caps_topics || m.caps_topic).skills_to_develop || [])
    .filter((s: string, i: number, arr: string[]) => arr.indexOf(s) === i)
  
  return {
    all_learning_outcomes: allOutcomes,
    all_skills_to_develop: allSkills,
    assessment_suggestion: `Create questions covering ${mappings.length} topic(s) with cognitive levels: ${
      [...new Set(mappings.map((m: any) => (m.caps_topics || m.caps_topic).cognitive_level))].join(', ')
    }`
  }
}

function distributeQuestions(total: number, numTopics: number, questionTypes: string[]) {
  const perTopic = Math.floor(total / numTopics)
  const remainder = total % numTopics
  
  const distribution: any[] = []
  
  for (let i = 0; i < numTopics; i++) {
    const topicQuestions = perTopic + (i < remainder ? 1 : 0)
    const perType = Math.floor(topicQuestions / questionTypes.length)
    
    distribution.push({
      topic_index: i,
      total_questions: topicQuestions,
      by_type: questionTypes.reduce((acc, type, idx) => {
        acc[type] = perType + (idx < topicQuestions % questionTypes.length ? 1 : 0)
        return acc
      }, {} as Record<string, number>)
    })
  }
  
  return distribution
}

/**
 * PostgreSQL RPC Function (to be added to migration)
 * 
 * CREATE OR REPLACE FUNCTION find_caps_topics_by_page_range(
 *   p_textbook_id UUID,
 *   p_page_start INTEGER,
 *   p_page_end INTEGER
 * )
 * RETURNS TABLE (...) AS $$
 * -- Implementation in migration file
 * $$ LANGUAGE plpgsql;
 */
